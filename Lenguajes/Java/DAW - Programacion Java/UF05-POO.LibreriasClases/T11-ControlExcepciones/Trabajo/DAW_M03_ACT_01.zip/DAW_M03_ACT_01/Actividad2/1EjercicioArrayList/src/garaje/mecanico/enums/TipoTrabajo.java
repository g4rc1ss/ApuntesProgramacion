package garaje.mecanico.enums;

public enum TipoTrabajo {
    reparacionMecanica,
    reparacionChapaPintura,
    revision
}
