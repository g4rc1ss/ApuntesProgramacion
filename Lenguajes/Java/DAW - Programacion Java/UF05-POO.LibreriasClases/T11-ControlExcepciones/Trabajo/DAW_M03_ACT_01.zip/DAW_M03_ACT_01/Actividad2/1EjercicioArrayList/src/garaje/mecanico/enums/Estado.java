package garaje.mecanico.enums;

public enum Estado {
    recibida_comenzada,
    finalizada
}
