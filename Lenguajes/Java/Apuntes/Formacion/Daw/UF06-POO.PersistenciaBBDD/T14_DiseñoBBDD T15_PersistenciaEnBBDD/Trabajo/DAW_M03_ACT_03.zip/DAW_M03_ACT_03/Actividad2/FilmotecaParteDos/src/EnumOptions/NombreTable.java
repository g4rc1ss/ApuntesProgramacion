package EnumOptions;

public enum NombreTable {
    pelicula,
    director
}
