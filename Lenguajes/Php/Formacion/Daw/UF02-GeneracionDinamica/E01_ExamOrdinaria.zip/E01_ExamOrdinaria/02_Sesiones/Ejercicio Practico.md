Supón que tenemos una aplicación en la que el usuario debe pasar por una página de login. Si introduce bien los datos, se guarda la variable “id_user” en la sesión.

Escribe el código que debería incluir la página “perfil.php” si quiero asegurar que el usuario no puede acceder a ella si no ha pasado previamente por el login. Es decir, si no se ha logueado, no podemos acceder a “perfil.php”, sino que se nos redireccionará a la página “login.php”.

Escribe también el código que debería tener una página “logout.php”.

No hace falta que escribas ningún código HTML. Especifica sobre todo lo que se pide.