Crea la siguiente estructura de clases en PHP:

Clase madre "Juego", con atributos nombre y edad_mínima
Clase hija "De_mesa", con atributos num_jugadores y tipo.
Clase hija "Videojuego", con atributos plataforma y género.
Las clases anteriores deben incluir todos los métodos (constructor, getters y setters, y toString).

Crea un script en el que se creen un par de juegos de cada tipo, guardados todos ellos en un mismo array.
A continuación, recorre el array diciendo, para cada juego, la frase "Soy un juego de mesa" o "Soy un videojuego" junto con sus datos.

