<html>

<body>
    <?php
    $alturaRectangulo = 2;
    $baseRectangulo = 4;
    $areaRectangulo = $baseRectangulo * $alturaRectangulo;
    $perimetroRectangulo = 2 * ($alturaRectangulo + $baseRectangulo);

    echo "El rectangulo tiene base " . $baseRectangulo . "cm y altura es " . $alturaRectangulo . "cm </br>";
    echo "su área es " . $areaRectangulo . "cm<sup>2</sup> </br>";
    echo "su perímetro es " . $perimetroRectangulo . "cm";
    ?>
</body>

</html>