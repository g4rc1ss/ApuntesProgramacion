<html>

<body>
    <?php
    $variableUno = 2;
    $variableDos = 3;
    $variableSumada = $variableUno + $variableDos;

    echo "variableUno = " . $variableUno . "</br>";
    echo "variableDos = " . $variableDos . "</br>";
    echo "variableSumada = " . $variableSumada;
    ?>
</body>

</html>