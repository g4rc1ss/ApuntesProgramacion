/* 

SELECT

FROM

[ WHERE ]

Otra forma de hacer elejercicio de ayer

SELECT E.NOM, E.DIR

FROM EMPLEADOS E, DPTOS D

WHERE E.COD-DPTO = D.COD-DPTO
	AND D.NOM-D = "INVESTIGACION";



ENUNCIADO:

	POR CADA PROYECTO UBICADO EN Z11 OBTENER EL CODIGO DE PROYECTO, EL CODIGO DEPARTAMENTO Y EL NOMBRE, DIRECCION Y FECHA DE NACIMIENTO DEL JEFE DEL DEPARTAMENTO

		SELECT

		FROM EMPLEADOS E, PROYECTOS P, DPTOS D

		WHERE P.COD-DPTO = D.COD-DPTO

			AND D.DNI-JEFE = E.DNI

			AND P.COD-ZONA = "ZONA"

TABLA PROYECYO:

COD-PROYECTO	DESCRIPCION		FECHA	PRESUPUESTO		CLAVE-DPTO		COD-ZONA

PROY1			AEROPUERTO		10/1/16		7			DPTO1				Z1
PROY2			CAFETERIA		5/2/17		8			DPTO1				Z1
PROY3			GASOLINERA		15/4/15		9			DPTO1				Z8
PROY4			TALLERES		10/2/00		3			DPTO2				Z1
PROY5			COCHES			3/4/16		9			DPTO1				Z1
PROY6			SUPERMERCADO	5/12/16		7			DPTO3				Z1
PROY7			A 				4/2/17		1			DPTO3				Z4

-----------------------------------------------------------------------------------

TABLA DPTOS:

COD-DPTO	NOMBRE			DNI-J	FECHA

DPTO1		RRHH				7	3/2/16
DPTO2		COMPRAS				3	4/3/2000
DPTO3		ALMACEN				2	5/8/10
DPTO4		CONTABILIDAD		4	4/3/15

-----------------------------------------------------------------------------------

TABLAS EMPLEADOS:

DNI 	NOMBRE		APEL1		APEL2	...		COD-DPTO		COD-ZONA	DNI-JEFE
1		_____________________________________	DPTO1				Z1 			1
2		_____________________________________	DPTO3				Z1
3		_____________________________________	DPTO2				Z1
4		_____________________________________	DPTO4				Z8
5		_____________________________________	DPTO1				Z1 			1
6		_____________________________________	DPTO1				Z1 			1
7		_____________________________________	DPTO1				Z8 			1
8		_____________________________________	DPTO3				Z1
9		_____________________________________	DPTO4				Z8
10		_____________________________________	DPTO3				Z1


SELECT P.COD-PROY, P.COD-DPTO, E.NOM, E.DIR, E.FECHANAC

FROM PROY P, EMPLE, DPTO D

WHERE P.COD-ZONA = "Z11"
	AND P.COD-DPTO = D.COD-CPTO
	AND D.DNI-J = E.DNI


--------------------------------------------------------------------------------------------

TEORIA:

	EN LA FROM IRIAN LOS NOMBRES DE LAS TABLAS DONDE COGEREMOS LOS ATRIBUTOS

	LO QUE QUIERES QUE SALGA TEMDRA QUE APARECER EN LA SELECT(PODRAN SER EXPRESIONES, CAMPOS ETC...), PARA MOSTRAR SOLO RSULTADOS QUE ESTAN REFLEJADOS EN UNA SOLA TABLA, CON PONER EL NOMBRE DE LOS CAMPOS SOBRA, PERO SI QUIERES MOSTRAR SOBRE UNA TABLA ESPECICIFICA PORQUE EN EL FROM HAY MAS DE UNA TABLA REFLEJADA, SE USARA DE LA SIGUIENTE FORMA:
	SELECT NOMBRETABLA.CAMPO...
	SI HAY QUE OPERAR POR ALGUN CASUAL SE PODRA HACER EN ESE MOMENTO, POR EJEMPLO SI QUIERES QUE EL RESULTADO DE LOS SUELDOS SEA ANUAL SE MULTIPLICARA LO QUE HAY EN EL CAMPO SUELDOS * 12 Y SE PODRA HACER DE LA SIGUIENTE FORMA:
	SELECT 


-----------------------------------------------------------------------------------------------------------
NOMBRE DE LOS EMPLEADOS CUYA COMISION ES SUPERIOR O IGUAL AL 50% DE SU SALARIO (COMISION ESTA EN LA TABLA DE EMPLEADOS)

SELECT NOMBRES

FROM EMPLEADOS

WHERE COMISION >= SALARIO

-------------------------------------------------------------------------------------------------------------

NOMBRE Y SALARIO TOTAL DE LOS EMPLEADOS QUE TENGAN 3 O MAS HIJOS(EL CAMPO NUMERO_HIJOS ESTA EN LA TABLA EMPLEADOS) EL SALARIO TOTAL = A SALARIO + 30e POR HIJO A PARTIR DEL TERCERO (INCLUIDO)

SELECT NOMBRE, SALARIO + ( 30 *( NUMHIJOS - 2 ) ) AS "SALARIO TOTAL"

FROM EMPLEADOS

WHERE NUMHIJOS >= 3

------------------------------------------------------------------------------------------------------------------

LISTADO DE SALARIOS DE LA EMPRESA

SELECT DISTINCT SALARIO

FROM EMPLEADOS