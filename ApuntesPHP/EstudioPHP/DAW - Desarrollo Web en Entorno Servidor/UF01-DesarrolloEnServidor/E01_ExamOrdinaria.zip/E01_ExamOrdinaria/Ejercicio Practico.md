Realiza una aplicación que conste dos páginas:

La primera se llamará ``formulario.html`` y presentará al usuario una página en la que se mostrará un formulario con los siguientes campos:

- Nombre, de tipo campo de texto.

- Edad, de tipo campo de texto.

- Aficiones, cuatro checkboxes con las opciones que quieras poner.
- Botón submit, que nos llevará a la siguiente página.

La segunda página se llamará “resultado.php”, y en ella se comprobará que el usuario ha introducido su nombre y su edad. Si no lo ha hecho, se mostrará el mensaje “Debes introducir tu nombre y tu edad”.

Si ha introducido ambos datos, se comprobará que la edad es como mínimo 18 años. En tal caso, se mostrará un saludo que incluirá el nombre del usuario y las aficiones que ha seleccionado. Si no ha seleccionado ninguna, se mostrará, junto con el nombre del usuario, el mensaje “No tienes aficiones”.

Si la edad introducida es menor de 18 años, se mostrará el mensaje “No puedes continuar”.

